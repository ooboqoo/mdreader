# marked

Repository Address / GitHub 地址: https://github.com/chjj/marked

A full-featured markdown parser and compiler, written in JavaScript. Built for speed.   
marked 是一个用 JavaScript 编写的高性能 markdown 解析和编译器。

如何使用请访问项目主页查看具体说明，同时别忘了 star 点赞哦！